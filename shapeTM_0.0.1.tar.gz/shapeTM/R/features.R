
#' Title
#'
#' @param path dir path
#' @param region gene region
#' @param select_region return regions to be selected
#' @param mini only input mini paramters
#' @param species species
#' @export
#'
merge_outputs_auto <- function(path,region="human_small",select_region=FALSE,mini=FALSE,species=NULL,noshape=FALSE){
  files <- dir(path,full.names = T)
  rf_count = NULL
  rf_director = NULL
  pipe_score = NULL
  pipe_output = NULL
  if(mini){
    for (file in files) {
      if(is_rf_count(file)){
        rf_count <- file
      }
      if(is_pipe_output(file)){
        pipe_output <- file
      }
    }
    # print(rf_count)
    # print(rf_director)
    # print(pipe_score)
    # print(pipe_output)
    cat(paste0("Input 1 - rf_count: ", rf_count, "\n"))
    cat(paste0("Input 2 - rf_director: NULL\n"))
    cat(paste0("Input 3 - pipe_score: NULL\n"))
    cat(paste0("Input 4 - pipe_output: ", pipe_output, "\n"))
    tab <- merge_outputs(rf_count = rf_count, pipe_output = pipe_output, region = region, select_region=select_region, species = species)
  }else{
    if(noshape){
      for (file in files) {
        if(is_rf_count(file)){
          rf_count <- file
        }
        if(is_rf_director(file)){
          rf_director <- file
        }
        if(is_pipe_output(file)){
          pipe_output <- file
        }
      }
      # print(rf_count)
      # print(rf_director)
      # print(pipe_score)
      # print(pipe_output)
      cat(paste0("Input 1 - rf_count: ", rf_count, "\n"))
      cat(paste0("Input 2 - rf_director: ", rf_director, "\n"))
      cat(paste0("Input 3 - pipe_score: NULL\n"))
      cat(paste0("Input 4 - pipe_output: ", pipe_output, "\n"))
      tab <- merge_outputs(rf_count = rf_count, rf_director = rf_director, pipe_output = pipe_output, region = region, select_region=select_region, species = species)
    }else{
      for (file in files) {
        if(is_rf_count(file)){
          rf_count <- file
        }
        if(is_rf_director(file)){
          rf_director <- file
        }
        if(is_pipe_score(file)){
          pipe_score <- file
        }
        if(is_pipe_output(file)){
          pipe_output <- file
        }
      }
      # print(rf_count)
      # print(rf_director)
      # print(pipe_score)
      # print(pipe_output)
      cat(paste0("Input 1 - rf_count: ", rf_count, "\n"))
      cat(paste0("Input 2 - rf_director: ", rf_director, "\n"))
      cat(paste0("Input 3 - pipe_score: ", pipe_score, "\n"))
      cat(paste0("Input 4 - pipe_output: ", pipe_output, "\n"))
      tab <- merge_outputs(rf_count = rf_count, rf_director = rf_director, pipe_score = pipe_score, pipe_output = pipe_output, region = region, select_region=select_region, species = species)
    }
  }
}

#' Merge RNAFramework and icSHAPE-pipe outputs
#' @description
#' Combind the outputs from RNAFramework and icSHAPE-pipe.
#' @param rf_count RNAFramework count output
#' @param rf_director RNAFramework mutation director
#' @param pipe_score icshape-pipe SHAPE score output
#' @param pipe_output icshape-pipe count output
#' @param region gene name
#' @param strand +/-/both
#' @param select_region return regions to be selected
#' @param species species
#' @import dplyr
#' @export
#' @examples
#' tab <- merge_outputs(rf_count="~/Downloads/RNAframework_mut_count.csv",
#' rf_director="~/Downloads/RNAframework_outputFile.txt",
#' pipe_score="~/Downloads/293ft_rRNA_shape_onlynai.out",
#' pipe_output="~/Downloads/count_RT_stop_outputFile.csv")
#' write.table(tab,"~/Downloads/features_added.txt",sep="\t",row.names = F,quote = F)
merge_outputs <- function(rf_count,rf_director=NULL,pipe_score=NULL,pipe_output,
                          region="human_small",strand="+",select_region=FALSE,species=NULL){
  # read files
  tab_mutation_count <- rf_read_mutation_count(rf_count)
  tab_truncation_count <- read_icshape_output(pipe_output)
  if(is.null(rf_director) && is.null(pipe_score)){

  }else{
    if(is.null(pipe_score)){
      df_rf_mut_director <- rf_read_mutation_director(rf_director)
    }else{
      df_rf_mut_director <- rf_read_mutation_director(rf_director)
      score_list <- read_icshape_score(pipe_score)
    }
  }

  if(select_region){
    print(unique(tab_mutation_count$ChrID))
  }

  # filter gene region
  tab_mutation_count <- tab_mutation_count %>% filter(ChrID == region)
  if(strand == "both"){
    tab_truncation_count <- tab_truncation_count %>% filter(ChrID == region)
  }else{
    tab_truncation_count <- tab_truncation_count %>% filter(ChrID == region) %>% filter(Strand == strand)
  }

  if(is.null(rf_director) && is.null(pipe_score)){

  }else{
    if(is.null(pipe_score)){
      df_rf_mut_director <- df_rf_mut_director %>% filter(ChrID == region)
    }else{
      df_rf_mut_director <- df_rf_mut_director %>% filter(ChrID == region)
      score_list <- score_list %>% filter(ChrID == region)
    }
  }

  # add prefix to column names
  names(tab_mutation_count)[2:length(names(tab_mutation_count))] <- paste0("rf_mutation_",names(tab_mutation_count)[2:length(names(tab_mutation_count))])
  names(tab_truncation_count)[2:length(names(tab_truncation_count))] <- paste0("pipe_truncation_",names(tab_truncation_count)[2:length(names(tab_truncation_count))])
  if(is.null(rf_director) && is.null(pipe_score)){

  }else{
    if(is.null(pipe_score)){
      names(df_rf_mut_director)[2:length(names(df_rf_mut_director))] <- paste0("rf_mutation_",names(df_rf_mut_director)[2:length(names(df_rf_mut_director))])
    }else{
      names(df_rf_mut_director)[2:length(names(df_rf_mut_director))] <- paste0("rf_mutation_",names(df_rf_mut_director)[2:length(names(df_rf_mut_director))])
      names(score_list)[2:length(names(score_list))] <- paste0("pipe_truncation_",names(score_list)[2:length(names(score_list))])
    }
  }

  # check point: data row number
  print(dim(tab_mutation_count))
  #print(tab_mutation_count)
  if(is.null(rf_director)){}else{print(dim(df_rf_mut_director))}
  if(is.null(pipe_score)){}else{print(dim(score_list))}
  #print(score_list)
  print(dim(tab_truncation_count))
  #print(tab_truncation_count)

  # check point: data
  # print(score_list)
  # print(nrow(tab_truncation_count))
  # print(ncol(tab_truncation_count))

  # create an empty matrix and add additional rows
  if(is.null(rf_director) && is.null(pipe_score)){
    if(nrow(tab_mutation_count) - nrow(tab_truncation_count)!=0){
      if(nrow(tab_mutation_count) - nrow(tab_truncation_count)>0){
        tab_mutation_count <- tab_mutation_count[1:nrow(tab_truncation_count),]
      }else{
        tab_truncation_count <- tab_truncation_count[1:nrow(tab_mutation_count),]
      }
    }
  }else{
    if(is.null(pipe_score)){
      if(nrow(df_rf_mut_director)-nrow(tab_truncation_count)!=0){
        if(nrow(df_rf_mut_director)-nrow(tab_truncation_count) >0){
          if(nrow(tab_truncation_count) == (tab_truncation_count[nrow(tab_truncation_count),3]-tab_truncation_count[1,3] +1)){
            tab_add <- data.frame(matrix(-1,nrow(df_rf_mut_director)-nrow(tab_truncation_count),ncol(tab_truncation_count)))
            colnames(tab_add) <- colnames(tab_truncation_count)
            # print(tab_add)
            tab_add[,1] <- tab_truncation_count[nrow(tab_truncation_count),1]
            tab_add[,2] <- tab_truncation_count[nrow(tab_truncation_count),2]
            # print(head(tab_truncation_count,30))
            # print(tail(tab_truncation_count,30))
            # print(tab_add)
            # print(as.numeric(tab_truncation_count[nrow(tab_truncation_count),3])+1)
            print(as.numeric(tab_truncation_count[nrow(tab_truncation_count),3])+1)
            print(nrow(df_rf_mut_director))
            print(tab_add)
            tab_add[,3] <- (as.numeric(tab_truncation_count[nrow(tab_truncation_count),3])+1):nrow(df_rf_mut_director)
            tab_truncation_count <- rbind(tab_truncation_count,tab_add)
          }else{
            # check outlier
            tab_truncation_count <- tab_truncation_count[which(tab_truncation_count[,2] == names(sort(table(tab_truncation_count[,2]),decreasing = T)[1])),]
            # check start and end
            #print(score_list)
            # print(tab_truncation_count)
            # print(nrow(tab_truncation_count))
            # print((tab_truncation_count[nrow(tab_truncation_count),3]-tab_truncation_count[1,3] +1))
            range_index <- 1:nrow(df_rf_mut_director)
            # print(range_index)
            # add row
            #x = 0
            while (nrow(tab_truncation_count) != (tab_truncation_count[nrow(tab_truncation_count),3]-tab_truncation_count[1,3] +1)) {
              #while(x<2){
              #x=x+1
              # print(nrow(tab_truncation_count))
              # print(tab_truncation_count[nrow(tab_truncation_count),3]-tab_truncation_count[1,3] +1)
              # print(tail(tab_truncation_count,22))
              for (i in range_index) {
                #cat(nrow(tab_truncation_count))
                #cat(tab_truncation_count[nrow(tab_truncation_count),3]-tab_truncation_count[1,3] +1)
                if(nrow(tab_truncation_count[which(tab_truncation_count[,3]==i),])==0){
                  #cat(2)
                  if(nrow(tab_truncation_count[which(tab_truncation_count[,3]==i-1),])!=0){
                    add_rows <- tab_truncation_count[which(tab_truncation_count[,3]==i-1),]
                  }else{
                    if(nrow(tab_truncation_count[which(tab_truncation_count[,3]==i+1),])!=0){
                      add_rows <- tab_truncation_count[which(tab_truncation_count[,3]==i+1),]
                    }else{
                      if(tab_truncation_count[1,3]!=1){
                        add_rows <- tab_truncation_count[1,]
                      }
                    }
                  }
                  add_rows[,3] <- i
                  add_rows[,4:ncol(add_rows)] <- NA
                  #print(add_rows)
                  tab_truncation_count <- rbind(tab_truncation_count,add_rows)
                  tab_truncation_count <- tab_truncation_count[order(tab_truncation_count[,3]),]
                }
              }
            }
          }
        }else{
          # pipe error fix: longer output than others
          tab_truncation_count <- tab_truncation_count[1:nrow(df_rf_mut_director),]
        }
      }
    }else{
      if(nrow(score_list)-nrow(tab_truncation_count)!=0){
        if(nrow(score_list)-nrow(tab_truncation_count) >0){
          if(nrow(tab_truncation_count) == (tab_truncation_count[nrow(tab_truncation_count),3]-tab_truncation_count[1,3] +1)){
            tab_add <- data.frame(matrix(-1,nrow(score_list)-nrow(tab_truncation_count),ncol(tab_truncation_count)))
            colnames(tab_add) <- colnames(tab_truncation_count)
            # print(tab_add)
            tab_add[,1] <- tab_truncation_count[nrow(tab_truncation_count),1]
            tab_add[,2] <- tab_truncation_count[nrow(tab_truncation_count),2]
            # print(head(tab_truncation_count,30))
            # print(tail(tab_truncation_count,30))
            # print(tab_add)
            # print(as.numeric(tab_truncation_count[nrow(tab_truncation_count),3])+1)
            print(as.numeric(tab_truncation_count[nrow(tab_truncation_count),3])+1)
            print(nrow(score_list))
            print(tab_add)
            tab_add[,3] <- (as.numeric(tab_truncation_count[nrow(tab_truncation_count),3])+1):nrow(score_list)
            tab_truncation_count <- rbind(tab_truncation_count,tab_add)
          }else{
            # check outlier
            tab_truncation_count <- tab_truncation_count[which(tab_truncation_count[,2] == names(sort(table(tab_truncation_count[,2]),decreasing = T)[1])),]
            # check start and end
            #print(score_list)
            # print(tab_truncation_count)
            # print(nrow(tab_truncation_count))
            # print((tab_truncation_count[nrow(tab_truncation_count),3]-tab_truncation_count[1,3] +1))
            range_index <- 1:score_list[1,3]
            # print(range_index)
            # add row
            #x = 0
            while (nrow(tab_truncation_count) != (tab_truncation_count[nrow(tab_truncation_count),3]-tab_truncation_count[1,3] +1)) {
              #while(x<2){
              #x=x+1
              # print(nrow(tab_truncation_count))
              # print(tab_truncation_count[nrow(tab_truncation_count),3]-tab_truncation_count[1,3] +1)
              # print(tail(tab_truncation_count,22))
              for (i in range_index) {
                #cat(nrow(tab_truncation_count))
                #cat(tab_truncation_count[nrow(tab_truncation_count),3]-tab_truncation_count[1,3] +1)
                if(nrow(tab_truncation_count[which(tab_truncation_count[,3]==i),])==0){
                  #cat(2)
                  if(nrow(tab_truncation_count[which(tab_truncation_count[,3]==i-1),])!=0){
                    add_rows <- tab_truncation_count[which(tab_truncation_count[,3]==i-1),]
                  }else{
                    if(nrow(tab_truncation_count[which(tab_truncation_count[,3]==i+1),])!=0){
                      add_rows <- tab_truncation_count[which(tab_truncation_count[,3]==i+1),]
                    }else{
                      if(tab_truncation_count[1,3]!=1){
                        add_rows <- tab_truncation_count[1,]
                      }
                    }
                  }
                  add_rows[,3] <- i
                  add_rows[,4:ncol(add_rows)] <- NA
                  #print(add_rows)
                  tab_truncation_count <- rbind(tab_truncation_count,add_rows)
                  tab_truncation_count <- tab_truncation_count[order(tab_truncation_count[,3]),]
                }
              }
            }
          }
        }else{
          # pipe error fix: longer output than others
          tab_truncation_count <- tab_truncation_count[1:nrow(score_list),]
        }
      }
    }
  }

  # print(dim(tab_mutation_count))
  # print(dim(df_rf_mut_director))
  # print(dim(score_list))
  # print(dim(tab_truncation_count))

#  print(dim(tab_truncation_count))
#  return(tab_truncation_count)
  if(is.null(rf_director) && is.null(pipe_score)){
    tab <- cbind(tab_mutation_count,tab_truncation_count[,-1])
    return(tab)
  }else{
    if(is.null(pipe_score)){
      #print(tab_truncation_count[,-1])
      tab <- cbind(tab_mutation_count,df_rf_mut_director[,-1],tab_truncation_count[,-1])
      tab_2 <- add_freature_base(tab)
      if(species != "nodot"){
        tab_2 <- add_freature_dot(tab_2,region,species)
      }
      return(tab_2)
    }else{
      #print(tab_truncation_count[,-1])
      tab <- cbind(tab_mutation_count,df_rf_mut_director[,-1],score_list[,-1],tab_truncation_count[,-1])
      tab_2 <- add_freature_base(tab)
      if(species != "nodot"){
        tab_2 <- add_freature_dot(tab_2,region,species)
      }
      return(tab_2)
    }
  }
}

#' Title
#'
#' @param tab
#'
#' @export
#'
add_freature_base <- function(tab){
  tab_2 <- tab %>% mutate(base_A = case_when( rf_mutation_Base == "A" ~ rf_mutation_Depth - rf_mutation_Count,rf_mutation_Base != "A" ~ rf_mutation_CA + rf_mutation_GA + rf_mutation_TA),
                          base_T = case_when( rf_mutation_Base == "T" ~ rf_mutation_Depth - rf_mutation_Count,rf_mutation_Base != "T" ~ rf_mutation_CT + rf_mutation_GT + rf_mutation_AT),
                          base_G = case_when( rf_mutation_Base == "G" ~ rf_mutation_Depth - rf_mutation_Count,rf_mutation_Base != "G" ~ rf_mutation_CG + rf_mutation_AG + rf_mutation_TG),
                          base_C = case_when( rf_mutation_Base == "C" ~ rf_mutation_Depth - rf_mutation_Count,rf_mutation_Base != "C" ~ rf_mutation_AC + rf_mutation_GC + rf_mutation_TC))
  # tab_2 <- tab_2 %>% mutate(base_A = case_when( base_A == 0 ~ 1.1, base_A == 1 ~ 1.1, !base_A %in% c(0,1) ~ base_A),
  #                           base_T = case_when( base_T == 0 ~ 1.1, base_T == 1 ~ 1.1, !base_T %in% c(0,1) ~ base_T),
  #                           base_G = case_when( base_G == 0 ~ 1.1, base_G == 1 ~ 1.1, !base_G %in% c(0,1) ~ base_G),
  #                           base_C = case_when( base_C == 0 ~ 1.1, base_C == 1 ~ 1.1, !base_C %in% c(0,1) ~ base_C))
  # tab_2 <- tab_2 %>% mutate(rate_AT = log10(base_A)/log10(base_T),
  #                         rate_AG = log10(base_A)/log10(base_G),
  #                         rate_AC = log10(base_A)/log10(base_C),
  #                         rate_TA = log10(base_T)/log10(base_A),
  #                         rate_TG = log10(base_T)/log10(base_G),
  #                         rate_TC = log10(base_T)/log10(base_C),
  #                         rate_GA = log10(base_G)/log10(base_A),
  #                         rate_GT = log10(base_G)/log10(base_T),
  #                         rate_GC = log10(base_G)/log10(base_C),
  #                         rate_CA = log10(base_C)/log10(base_A),
  #                         rate_CT = log10(base_C)/log10(base_T),
  #                         rate_CG = log10(base_C)/log10(base_G))

  return(tab_2)
}

#' Title
#'
#' @param tab input
#' @param region gene
#' @param species species
#'
#' @export
#'
# add_freature_dot <- function(tab, file, region,keep_all=FALSE){
#   regions <- unique(tab$ChrID)
#   for (i in 1:length(regions)) {
#     sub_df <- tab %>% filter(ChrID == regions[i])
#     dot <- read_dot(file,vertical = TRUE,region = region)
#     if(nrow(dot))
#     sub_df <- cbind(sub_df, dot[,3:4])
#
#   }
#   tab <- tab %>% mutate(structure_value = shapeTM::convert_dot(structure_symbol))
#   return(tab)
# }
add_freature_dot <- function(tab, region, species=NULL){
  default_species = species
  species = stringr::str_extract(region,"^.*_")
  gene = stringr::str_extract(region,"_.*$")
  if(is.na(species)){
    species = paste0(default_species,"_")

  }
  if(grepl("small",gene)){
    file = system.file("extdata",paste0(species,"18s.csv"),package = "shapeTM")
  }
  if(grepl("large",gene)){
    file = system.file("extdata",paste0(species,"28s.csv"),package = "shapeTM")
  }
  if(grepl("7SK",region) | grepl("X04236",region)){
    file = system.file("extdata",paste0("human_7SK.csv"),package = "shapeTM")
  }
  if(grepl("SRP",region) | grepl("X04248",region)){
    file = system.file("extdata",paste0("human_SRP.csv"),package = "shapeTM")
  }
  if(species == "ecoli_"){
    if(grepl("16s",gene)){
      file = system.file("extdata",paste0(species,"16s.csv"),package = "shapeTM")
    }
    if(grepl("23s",gene)){
      file = system.file("extdata",paste0(species,"23s.csv"),package = "shapeTM")
    }
  }
  dot <- read.table(file,header = T)
  tab$modified_string <- dot[,1]
  return(tab)
}

#' Title
#'
#' @param tab input
#'
#' @export
#'
singnature_ratio <- function(tab){
  rate_truncation <- mean(tab[,names(tab)[startsWith(names(tab),"pipe")][6]]/tab[,names(tab)[startsWith(names(tab),"pipe")][7]])
  rate_mutation <- mean(tab$rf_mutation_Count/tab$rf_mutation_Depth)
  ratio <- rate_truncation/rate_mutation
  return(ratio)
}

add_pc <- function(tab){
  tab_new <- tab[, !sapply(tab, is.character)]
  t_tab = data.frame(t(tab_new))
  colnames(t_tab) = rownames(tab_new)
  rownames(t_tab) = colnames(tab_new)
  result <- summary(vegan::rda(t_tab))
  tab_pc <- cbind(tab,result$species)
}
