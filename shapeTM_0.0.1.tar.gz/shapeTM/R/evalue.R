#' AUC in ROC
#' @description
#' input two vector, return an auc value to evalue the accuracy of one method
#' @param actual a vector of 0/1 true result
#' @param predicted a vector of calculated result by real data
#' @param plot return roc plot, default is FALSE
#' @importFrom mltools auc_roc
#' @import ggplot2
#' @return auc score or roc plot
#' @export
#' @examples
#' actual <- c(0,0,1,1,1,0,0)
#' predicted <- c(0.10, 0.30, 0.40, 0.90, 0.76, 0.55, 0.20)
#' auc(actual = actual, predicted = predicted, plot = T)
auc <- function(actual,predicted,plot=FALSE){
  score <- auc_roc(predicted, actual)
  df <- auc_roc(predicted, actual,returnDT = T)
  if(plot){
    p <- ggplot(df) +
      geom_line(aes(x = CumulativeFPR,y=CumulativeTPR)) +
      xlim(0,1) +
      theme_bw() +
      ggtitle(paste0('ROC Curve ', '(AUC = ', round(score,3), ')'))
    print(p)
  }
  return(list(score,df))
}

#' Dot convert
#' @description
#' Convert dot to 0/1
#' @param str a vector of characters for dot(single strand) or others(double
#' strand). single base is marked as 1, paired base is marked as 0.
#' @importFrom stringr str_replace_all
#' @export
#' @examples
#' str_1 <- c(".",".","(",")",".",".","<",">",".",".")
#' str_2 <- "..()..<>.."
#' convert_dot(str_1)
#' convert_dot(str_2)
convert_dot <- function(str){
  if(length(str) == 1 && nchar(str) > 1){
    str = unlist(strsplit(str,split = ""))
  }
  str <- stringr::str_replace_all(str,"\\.","1")
  str <- stringr::str_replace_all(str,"[^1]","0")
  return(str)
}
