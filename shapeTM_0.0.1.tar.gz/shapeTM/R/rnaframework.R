#' Read mutation directory
#' @description
#' read the output from rnaframework software, which contains the mutation
#' directory information.
#'
#' @param file input file
#' @importFrom dplyr bind_rows
#' @returns a data frame contains the mutation directory information.
#' @export
#' @examples
#' path = system.file("extdata","02_mapping_known_293ftn1.txt",package = "shapeTM")
#' df <- rf_read_mutation_director(file = path)
#'
rf_read_mutation_director <- function(file){
lines <- readLines(file)
lines <- lines[which(lines!="")]
list <- list()
for (i in 1:length(lines)) {
  if (i %% 15 == 1) {
    ChrID <- lines[i]
  }
  if (i %% 15 == 2) {
    AC <- as.numeric(unlist(strsplit(strsplit(lines[i],"\t")[[1]][2],",")))
  }
  if (i %% 15 == 3) {
    AG <- as.numeric(unlist(strsplit(strsplit(lines[i],"\t")[[1]][2],",")))
  }
  if (i %% 15 == 4) {
    AT <- as.numeric(unlist(strsplit(strsplit(lines[i],"\t")[[1]][2],",")))
  }
  if (i %% 15 == 5) {
    CA <- as.numeric(unlist(strsplit(strsplit(lines[i],"\t")[[1]][2],",")))
  }
  if (i %% 15 == 6) {
    CG <- as.numeric(unlist(strsplit(strsplit(lines[i],"\t")[[1]][2],",")))
  }
  if (i %% 15 == 7) {
    CT <- as.numeric(unlist(strsplit(strsplit(lines[i],"\t")[[1]][2],",")))
  }
  if (i %% 15 == 8) {
    GA <- as.numeric(unlist(strsplit(strsplit(lines[i],"\t")[[1]][2],",")))
  }
  if (i %% 15 == 9) {
    GC <- as.numeric(unlist(strsplit(strsplit(lines[i],"\t")[[1]][2],",")))
  }
  if (i %% 15 == 10) {
    GT <- as.numeric(unlist(strsplit(strsplit(lines[i],"\t")[[1]][2],",")))
  }
  if (i %% 15 == 11) {
    TA <- as.numeric(unlist(strsplit(strsplit(lines[i],"\t")[[1]][2],",")))
  }
  if (i %% 15 == 12) {
    TC <- as.numeric(unlist(strsplit(strsplit(lines[i],"\t")[[1]][2],",")))
  }
  if (i %% 15 == 13) {
    TG <- as.numeric(unlist(strsplit(strsplit(lines[i],"\t")[[1]][2],",")))
  }
  if (i %% 15 == 14) {
    ins <- as.numeric(unlist(strsplit(strsplit(lines[i],"\t")[[1]][2],",")))
  }
  if (i %% 15 == 0) {
    del <- as.numeric(unlist(strsplit(strsplit(lines[i],"\t")[[1]][2],",")))
    list[[i/15]] <- data.frame(ChrID = ChrID, AC = AC, AG = AG, AT = AT, CA = CA, CG = CG,
                     CT = CT, GA = GA, GC = GC, GT = GT, TA = TA, TC = TC, TG = TG,
                     ins = ins, del = del)
  }
}
df <- dplyr::bind_rows(list)

return(df)

}

#' Title
#'
#' @param file
#'
#' @export
#'
is_rf_director <- function(file){
  lines <- readLines(file)
  !grepl("\t",lines[1]) && !grepl(" ",lines[1]) && grepl("^AC",lines[2])
}

#' Title
#'
#' @param file
#'
#' @export
#'
rf_read_mutation_count <- function(file){
#  print(file)
  lines <- readLines(file)
  lines <- stringr::str_remove(lines,",,")
#  print(lines)
  index <- which(lines == "")
#  print(index)
  list <- list()
  for (i in 1:(length(index))) {
    if(i == 1){
      ChrID = lines[1]
      body = lines[2:(index[1]-1)]
    }else{
      ChrID = lines[index[i-1]+1]
      body = lines[(index[i-1]+2):(index[i]-1)]
    }
    df_body <- read.csv(text = body,header = F)
    list[[i]] <- data.frame(ChrID = ChrID, Base = df_body$V1, Count = df_body$V2, Depth = df_body$V3)
  }
  df <- dplyr::bind_rows(list)
  return(df)
}

#' Title
#'
#' @param file
#'
#' @export
#'
is_rf_count <- function(file){
  lines <- readLines(file)
  !grepl("\t",lines[1]) && !grepl(" ",lines[1]) && !grepl("^AC",lines[2])
}
