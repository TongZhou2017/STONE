# file = "~/Documents/个人材料/主导项目/贝叶斯/Parsed_Structure/human.dot"
# lines <- readLines(file)
# file_2 = "~/Downloads/293ft_RT_count.gTab"
# tab_count <- data.table::fread(file_2)
# sequence <- paste0(tab_count$V4,collapse = "")
# n=1
# label = c()
# seq = c()
# dot = c()
# for (i in 1:length(lines)) {
#   if(i %% 3 == 1){
#     label[n] <- lines[i]
#   }
#   if(i %% 3 == 2){
#     seq[n] <- lines[i]
#   }
#   if(i %% 3 == 0){
#     dot[n] <- lines[i]
#     n = n + 1
#   }
# }
# seq <- stringr::str_replace_all(seq,"U","T")
#
# df <- data.frame(seq_name = label, sequence = seq)
# library(itol.toolkit)
# itol.toolkit::fa_write(df,"~/Downloads/true_structures.fa")
# df2 <- data.frame(seq_name = "ref", sequence = sequence)
# itol.toolkit::fa_write(df2,"~/Downloads/ref.fa")
#
# bwa index ref.fa
# ~/data/shapeTM$ ~/software/rna_structure/ncbi-blast-2.15.0+/bin/makeblastdb -in ref.fa -dbtype nucl -title ref_blast
# ~/data/shapeTM$ ~/software/rna_structure/ncbi-blast-2.15.0+/bin/blastn -db ref.fa -strand both -num_threads 6 -query true_structures.fa -out out_blast_customfmt.txt -outfmt "6 qseqid sseqid pident length mismatch gapopen qstart qend sstart send evalue bitscore qlen sstrand"
#
# bowtie2-build ref.fa ref_bowtie2
# seqtk seq -F "#" true_structures.fa > true_structures.fq
# bowtie2 -x ref_bowtie2 -f true_structures.fa -S out_bowtie2.sam
#
# tab_blast <- data.table::fread("~/Downloads/out_blast_customfmt_ref38.txt",header = F)
# tab_blast <- tab_blast %>% filter(V4 > V13-10) %>% filter(V3 > 98)
#
# ~/data/shapeTM$ ~/software/microbiome/usearch -cluster_fast  true_structures.fa -id 0.8 -centroids selected_0.8_true_structures.fa -uc  selected_0.8_true_structures.uc

#' Read dot file
#' @description
#' Read RNA structure dot file into data frame
#' @param file file path
#' @param vertical output dataframe every base as one row
#' @param region output selected gene region
#' @import dplyr
#' @importFrom data.table fread
#' @importFrom stringr str_replace_all
#' @export
read_dot <- function(file,vertical=FALSE,region="ALL"){
  lines <- readLines(file)
  n=1
  label = c()
  seq = c()
  dot = c()
  for (i in 1:length(lines)) {
    if(i %% 3 == 1){
      label[n] <- stringr::str_remove(lines[i],"^>")
    }
    if(i %% 3 == 2){
      seq[n] <- lines[i]
    }
    if(i %% 3 == 0){
      dot[n] <- lines[i]
      n = n + 1
    }
  }
  seq <- stringr::str_replace_all(seq,"U","T")
  df <- data.frame(seq_name = label, sequence = seq, structure = dot)
  if(region == "ALL"){

  }else{
    df <- df %>% filter(seq_name %in% region)
  }
  if(vertical){
    regions <- unique(df$seq_name)
    vertical_list <- list()
    for (j in 1:length(regions)) {
      sub_df <- df %>% filter(seq_name == regions[j])
      vertical_sequence <- unlist(strsplit(sub_df$sequence,""))
      vertical_structure <- unlist(strsplit(sub_df$structure,""))
      vertical_list[[j]] <- data.frame(seq_name = rep(regions[j],length(vertical_sequence)), sequence = vertical_sequence, structure_symbol = vertical_structure)
    }
    df <- dplyr::bind_rows(vertical_list)
  }
  df <- df %>% mutate(structure_value = shapeTM::convert_dot(structure_symbol))
  return(df)
}

