# library(RRNA)
# ct <- makeCt(dot[980],seq[980])
# dat=ct2coord(ct)
# RNAPlot(dat,nt=TRUE)
#
# ct2 <- makeCt(dot[874],seq[874])
# dat2=ct2coord(ct2)
# RNAPlot(dat2,nt=TRUE,main = label[874])
