#' Read icshape-pipe outout
#' @description
#' The output of icshape-pipe is a csv file with header start with column names
#' in lines. Here we use readLines and read.csv to achieve read the output file
#' into a dataframe in R.
#' @param file the output file of icshape-pipe
#' @importFrom stringr str_remove
#' @export
read_icshape_output <- function(file){
  lines <- readLines(file)
  col_number <- as.numeric(stringr::str_remove(lines[1], "@ColNum "))
  col_names <- stringr::str_remove(stringr::str_remove(lines[2:(1+col_number)],"^@")," \\d+$")
  tab_truncation_count <- read.csv(text = lines[(2+col_number):length(lines)],header = F)
  colnames(tab_truncation_count) <- col_names
  return(tab_truncation_count)
}

#' Title
#'
#' @param file
#'
#' @export
#'
is_pipe_output <- function(file){
  lines <- readLines(file)
  grepl("^@ColNum",lines[1])
}

#' Title
#'
#' @param file
#'
#' @export
#'
read_icshape_score <- function(file){
  lines <- readLines(file)
  tab_pipe_shape <- list()
  for (i in 1:length(lines)) {
    line <- unlist(strsplit(lines[i],"\t"))
    gene <- line[1]
    length <- line[2]
    rpkm <- line[3]
    tab_pipe_shape[[i]] <- data.frame(ChrID = gene, ShapeScore = line[4:length(line)], Length = length, RPKM = rpkm)
  }
  score_df <- dplyr::bind_rows(tab_pipe_shape)
  return(score_df)
}

#' Title
#'
#' @param file
#'
#' @export
#'
is_pipe_score <- function(file){
  lines <- readLines(file)
  grepl("\t",lines[1])
}
