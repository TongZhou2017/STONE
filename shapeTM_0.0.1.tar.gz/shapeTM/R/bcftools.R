#' bcftools wrapper
#'
#' @description Wrapper function for bcftools. Check host local first, then check
#' docker container environment. Should setup the option parameter by the guide
#' in document.
#' @param command a character string specifying the bcftools command, which start
#' with 'bcftools'. In docker environment, single quote is defualt for command
#' transform. Double quote should be avoid to be used in command.
#' @return stdout screen from bcftools
#' @export
#' @examples
#' options(bcftools.path = '/home/zhoutong/anaconda3/envs/bcftools/bin/')
#' run_bcftools(command = "bcftools --help")
run_bcftools <- function(command){
  if(is.null(getOption("bcftools.path"))){
    stop("Please setup bcftools environment parameters by 'Setup' section in document")
  }
  if(file.exists(paste0(getOption("bcftools.path"),"bcftools"))){
    system(command = paste0(getOption("bcftools.path"),command),ignore.stdout = F)
  }
}
